'''
'''

#configuration
MY_CONSUMER_KEY = 'L5OU4Q0Bawj3wY53K4gEH4AFS'
MY_CONSUMER_SECRET = 'RzS1hRdsruln3SqNVdcj5w2VkIFn5KmNfAIPSsJiMt9IskIh5T'
MY_ACCESS_TOKEN_KEY = '854474386094600193-6JtXPcfxi0Ce0rf8fp3isrstchnhA5O'
MY_ACCESS_TOKEN_SECRET = 'koZlgSSkP4KtS9mWaaysTUhxHSsQHOkWM4v0VcRZoDSIt'

SOURCE_ACCOUNTS = ["cavs"] #A list of comma-separated, quote-enclosed Twitter handles of account that you'll generate tweets based on. It should look like ["account1", "account2"]. If you want just one account, no comma needed.
ODDS = 4 #How often do you want this to run? 1/8 times?
ORDER = 1 #how closely do you want this to hew to sensical? 1 is low and 3 is high.
DEBUG = True #Set this to False to start Tweeting live
STATIC_TEST = True #Set this to True if you want to test Markov generation from a static file instead of the API.
TEST_SOURCE = "testcorpus.txt" #The name of a text file of a string-ified list for testing. To avoid unnecessarily hitting Twitter API. You can use the included testcorpus.txt, if needed.
TWEET_ACCOUNT = "eriewateralerts" #The name of the account you're tweeting to.
